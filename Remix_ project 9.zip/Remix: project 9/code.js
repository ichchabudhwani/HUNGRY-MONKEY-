var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["b843b0ab-83e6-4bb4-9d0a-e88a42bfd9a4","cb576eb7-f97a-451a-a0c4-035f1a9cb605","38f1d853-f050-4962-9c90-983982480688","3bff0273-6244-483f-9966-14e721bc40f7"],"propsByKey":{"b843b0ab-83e6-4bb4-9d0a-e88a42bfd9a4":{"name":"tree","sourceUrl":"assets/api/v1/animation-library/gamelab/6M6MI5k464mg5p8h89sU8tyvtAbANGea/category_backgrounds/meadow.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"6M6MI5k464mg5p8h89sU8tyvtAbANGea","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/6M6MI5k464mg5p8h89sU8tyvtAbANGea/category_backgrounds/meadow.png"},"cb576eb7-f97a-451a-a0c4-035f1a9cb605":{"name":"monkey","sourceUrl":"assets/api/v1/animation-library/gamelab/dLPtht4VwuBuIZLbmtG28ktdnZ8FMLT_/category_animals/chimps.png","frameSize":{"x":387,"y":397},"frameCount":1,"looping":true,"frameDelay":2,"version":"dLPtht4VwuBuIZLbmtG28ktdnZ8FMLT_","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":387,"y":397},"rootRelativePath":"assets/api/v1/animation-library/gamelab/dLPtht4VwuBuIZLbmtG28ktdnZ8FMLT_/category_animals/chimps.png"},"38f1d853-f050-4962-9c90-983982480688":{"name":"banana","sourceUrl":"assets/api/v1/animation-library/gamelab/pWFbbj15zL1DL.xT.w9LmvN_ZdtcMo_W/category_food/face_banana.png","frameSize":{"x":264,"y":397},"frameCount":1,"looping":true,"frameDelay":2,"version":"pWFbbj15zL1DL.xT.w9LmvN_ZdtcMo_W","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":264,"y":397},"rootRelativePath":"assets/api/v1/animation-library/gamelab/pWFbbj15zL1DL.xT.w9LmvN_ZdtcMo_W/category_food/face_banana.png"},"3bff0273-6244-483f-9966-14e721bc40f7":{"name":"apple","sourceUrl":"assets/api/v1/animation-library/gamelab/R5HU7H.MzPJgfu.WtncglTeef4BzKuzc/category_food/apple_1.png","frameSize":{"x":333,"y":399},"frameCount":1,"looping":true,"frameDelay":2,"version":"R5HU7H.MzPJgfu.WtncglTeef4BzKuzc","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":333,"y":399},"rootRelativePath":"assets/api/v1/animation-library/gamelab/R5HU7H.MzPJgfu.WtncglTeef4BzKuzc/category_food/apple_1.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var tree = createSprite(200,230);
 tree.setAnimation("tree");

var endpoint = createSprite(395,167,10,250);
endpoint.shapeColor="orange";

var monkey= createSprite(40, 100,100,100);
monkey.setAnimation("monkey");
monkey.scale=0.2;
monkey.velocityX=0;
monkey.velocityY=0;



var banana1 = createSprite(120, 150,10,10);
banana1.setAnimation("banana");
banana1.scale=0.1;
banana1.velocityY=4;

var apple1 = createSprite(200, 150,10,10);
apple1.setAnimation("apple");
apple1.scale=0.1;
apple1.velocityY=-4;


var banana2 = createSprite(280, 150,10,10);
banana2.setAnimation("banana");
banana2.scale=0.1;
banana2.velocityY=4;

var apple2 = createSprite(350, 150,10,10);
apple2.setAnimation("apple");
apple2.scale=0.1;
apple2.velocityY=-4;



 

function draw() {
//background(tree)
background("white");


  

if (monkey.isTouching(endpoint)) {
textSize(20);
stroke("black");


text("you win!!",163,15) ; 
}
if (monkey.isTouching(apple1)||monkey.isTouching(apple2)) {
 playSound("assets/category_animals/monkey.mp3",false);

}
if (monkey.isTouching(banana1)||monkey.isTouching(banana2)) {
 playSound("assets/category_animals/monkey.mp3",false);
}




        


createEdgeSprites();
banana1.bounceOff(edges);
banana2.bounceOff(edges);
apple1.bounceOff(edges);
apple2.bounceOff(edges);

monkey.bounce(edges);


if (keyDown("right")) {
monkey.x=monkey.x+2;
  
}
if (keyDown("LEFT")) {
monkey.x=monkey.x-2;
}
if (keyDown("down")) {
monkey.y=monkey.y+2;
}
if (keyDown("up")) {
monkey.y=monkey.y-2;
}


if (monkey.isTouching(apple1)||monkey.isTouching(apple2)) {

monkey.x=0;
monkey.x=0;
 playSound("assets/category_animals/monkey.mp3",false);

}
if (monkey.isTouching(banana1)||monkey.isTouching(banana2)) {

monkey.x=0;
monkey.x=0;
  playSound("assets/category_animals/monkey.mp3",false);

}



drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
